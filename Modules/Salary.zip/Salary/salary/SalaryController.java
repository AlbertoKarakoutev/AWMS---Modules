package com.company.awms.modules.ext.salary;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.awms.modules.base.employees.EmployeeService;
import com.company.awms.modules.base.employees.data.Employee;
import com.company.awms.security.EmployeeDetails;

@Controller
@RequestMapping("/salary")
public class SalaryController {

	private SalaryService salaryService;
	private EmployeeService employeeService;

	@Autowired
	public SalaryController(SalaryService salaryService, EmployeeService employeeService) {
		this.salaryService = salaryService;
		this.employeeService = employeeService;
	}

	@GetMapping
	public String getSalary(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model) throws IOException {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		if (!salaryService.isActive()){
			return "errors/notFound";
		}

		try {
			Employee employee = employeeService.getEmployee(employeeDetails.getID());

			double workHours = salaryService.calculateWorkHours(employee);
			double totalSalary = salaryService.estimateSalary(employee);
			double salary = employee.getSalary();
			double taskRewards = totalSalary - (workHours * employee.getPayPerHour() + salary);

			model.addAttribute("workHours", workHours);
			model.addAttribute("totalSalary", totalSalary);
			model.addAttribute("salary", salary);
			model.addAttribute("taskRewards", taskRewards);
			model.addAttribute("nationalID", employee.getNationalID());
			model.addAttribute("payPerHour", employee.getPayPerHour());
			injectLoggedInEmployeeInfo(model, employeeDetails, employee);

			return "ext/salary/salary";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}

}
