package com.company.awms.modules.ext.salary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.company.awms.modules.base.employees.EmployeeService;
import com.company.awms.modules.base.employees.data.Employee;
import com.company.awms.security.EmployeeDetails;

@Controller
@RequestMapping("/salary")
public class SalaryController {

	private static boolean active = true;

	private SalaryService salaryService;
	private EmployeeService employeeService;

	@Autowired
	public SalaryController(SalaryService salaryService, EmployeeService employeeService) {
		this.salaryService = salaryService;
		this.employeeService = employeeService;
	}

	@GetMapping
	public String getSalary(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model) {
		if (!active) {
			return "errors/notFound";
		}

		try {
			Employee employee = employeeService.getEmployee(employeeDetails.getID());

			double workHours = this.salaryService.calculateWorkHours(employee);
			double totalSalary = salaryService.estimateSalary(employee);
			double salary = employee.getSalary();
			double taskRewards = totalSalary - (workHours * employee.getPayPerHour() + salary);

			model.addAttribute("workHours", workHours);
			model.addAttribute("totalSalary", totalSalary);
			model.addAttribute("salary", salary);
			model.addAttribute("taskRewards", taskRewards);
			model.addAttribute("nationalID", employee.getNationalID());
			model.addAttribute("payPerHour", employee.getPayPerHour());
			injectLoggedInEmployeeInfo(model, employeeDetails, employee);

			return "ext/salary/salary";
		} catch (Exception e) {
			e.printStackTrace();
			return "erorrs/internalServerError";
		}
	}
	
	private void injectLoggedInEmployeeInfo(Model model, EmployeeDetails employeeDetails, Employee employee) {
		model.addAttribute("employeeName", employeeDetails.getFirstName() + " " + employeeDetails.getLastName());
		model.addAttribute("employeeEmail", employeeDetails.getUsername());
		model.addAttribute("employeeID", employeeDetails.getID());
		int unread = 0;
		for(int i = 0; i < employee.getNotifications().size(); i++) {
			if(!employee.getNotifications().get(i).getRead()) {
				unread++;
			}
		}
		model.addAttribute("notifications", employee.getNotifications());
		model.addAttribute("unread", unread);
	}

	public static boolean getActive() {
		return active;
	}

	public static void setActive(boolean newActive) {
		active = newActive;
	}
}
