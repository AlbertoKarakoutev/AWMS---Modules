package com.company.awms.modules.ext.projects;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.company.awms.modules.base.admin.data.Module;
import com.company.awms.modules.base.admin.data.ModuleRepo;
import com.company.awms.modules.base.documents.data.Doc;
import com.company.awms.modules.base.employees.data.Employee;
import com.company.awms.modules.base.employees.data.EmployeeRepo;
import com.company.awms.modules.base.employees.data.Notification;
import com.company.awms.modules.ext.projects.data.Project;
import com.company.awms.modules.ext.projects.data.ProjectRepo;
import com.company.awms.modules.ext.projects.data.Step;

@Service
public class ProjectService {

	private EmployeeRepo employeeRepo;
	private ProjectRepo projectRepo;
	private ModuleRepo moduleRepo;

	@Autowired
	public ProjectService(EmployeeRepo employeeRepo, ProjectRepo projectRepo, ModuleRepo moduleRepo) {
		this.employeeRepo = employeeRepo;
		this.projectRepo = projectRepo;
		this.moduleRepo = moduleRepo;
	}

	public Employee getEmployee(String employeeID) throws IOException {
		Optional<Employee> employee = employeeRepo.findById(employeeID);
		if (employee.isEmpty()) {
			throw new IOException("Employee not found!");
		}
		return employee.get();
	}
	
	public Project getProject(String projectID) throws IOException{
		Optional<Project> project = projectRepo.findById(projectID);
		if (project.isEmpty()) {
			throw new IOException("Project not found!");
		}
		return project.get();
	}
	
	public Project createProject(Object projectObj, String creatorID) throws IOException {
		@SuppressWarnings("unchecked")
		JSONObject projectJSON = new JSONObject((Map<Object, String>) projectObj);
		
		Employee creator = getEmployee(creatorID);
		
		Project newProject = new Project((String)projectJSON.get("title"), (String)projectJSON.get("body"), creatorID, creator.getFirstName() + " " + creator.getLastName(), LocalDateTime.now(), creator.getDepartment());
		if(projectJSON.get("deadline")!=null) {
			newProject.setDeadline(LocalDate.parse((String)(projectJSON.get("deadline"))));
		}
		
		projectRepo.save(newProject);
		
		return newProject;
	}
	
	public String updateProject(Object projectObj, String employeeID) throws IOException, IllegalAccessException {
		@SuppressWarnings("unchecked")
		JSONObject projectJSON = new JSONObject((Map<Object, String>) projectObj);
		
		Project updatedProject = getProject((String)projectJSON.get("projectID"));

		if(!updatedProject.getCreatorID().equals(employeeID)) {
			throw new IllegalAccessException();
		}
		
		updatedProject.setTitle((String)projectJSON.get("title"));
		updatedProject.setBody((String)projectJSON.get("body"));
		
		if(projectJSON.get("deadline")!=null) {
			updatedProject.setDeadline(LocalDate.parse((String)(projectJSON.get("deadline"))));
		}else {
			updatedProject.setDeadline(null);
		}
		
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		updatedProject.log("[" + dateTime + "] The project has been updated.\n"); 
		
		projectRepo.save(updatedProject);
		
		return updatedProject.getID();
		
	}
	
	public List<Project> getAccessibleProjects(String viewerID) throws IOException {
		Employee viewer = getEmployee(viewerID);

		return projectRepo.findByDepartment(viewer.getDepartment());
	}

	public List<Project> getAccessibleProjectsDTOsByPage(String viewerID, Integer page) throws IOException {
		
		List<Project> projects = getAccessibleProjects(viewerID);
		
		List<Project> projectsPage = new ArrayList<>();

		if(page-1*10 > projects.size()) {
			return getAccessibleProjectsDTOsByPage(viewerID, 1);
		}
		
		for(int i = 0; i < projects.size(); i++) {
			if(i >= (page-1)*10 && i < page*10){
				Project projectDTO = new Project(projects.get(i).getTitle(), projects.get(i).getBody(), projects.get(i).getCreatorID(), projects.get(i).getCreatorName(), projects.get(i).getInitializationTime(), projects.get(i).getDepartment());
				projectDTO.setClosed(projects.get(i).isClosed());
				projectDTO.setID(projects.get(i).getID());
				if(projectDTO.isClosed()) {
					projectDTO.setCloserID(projects.get(i).getCloserID());
				}
				if(projects.get(i).getDeadline() != null) {
					projectDTO.setDeadline(projects.get(i).getDeadline());
				}
				projectsPage.add(projectDTO);
			}
		}
		
		return projectsPage;
	}
	
	public List<Project> searchProjects(List<Project> projects, String searchTerm) {
		List<Project> foundDocuments = new ArrayList<>();

		Pattern pattern = Pattern.compile(searchTerm, Pattern.CASE_INSENSITIVE);

		for (Project project : projects) {
			Matcher matcher = pattern.matcher(project.getTitle());
			boolean title = matcher.find();
			if (title) {
				foundDocuments.add(project);
				continue;
			}
			matcher = pattern.matcher(project.getBody());
			boolean body = matcher.find();
			if (body) {
				foundDocuments.add(project);
				continue;
			}
			matcher = pattern.matcher(project.getCreatorName());
			boolean creatorName = matcher.find();
			if (creatorName) {
				foundDocuments.add(project);
				continue;
			}
			if(project.getCloserName()!=null) {
				matcher = pattern.matcher(project.getCloserName());
				boolean closerName = matcher.find();
				if (closerName) {
					foundDocuments.add(project);
					continue;
				}
			}
			matcher = pattern.matcher(project.getDepartment());
			boolean department = matcher.find();
			if (department) {
				foundDocuments.add(project);
				continue;
			}
			matcher = pattern.matcher(project.getLog());
			boolean log = matcher.find();
			if (log) {
				foundDocuments.add(project);
				continue;
			}
		}
		return foundDocuments;
	}
	
	public boolean isActive() throws IOException{
		Optional<Module> moduleOptional = moduleRepo.findByName("projects");
		if(moduleOptional.isEmpty()){
			throw new IOException("Module not found!");
		}
		return moduleOptional.get().isActive();
	}

	public Doc getDocument(String projectID, String documentName, String employeeID) throws IOException {
		Employee employee = getEmployee(employeeID);
		Project project = getProject(projectID);
		Employee projectCreator = getEmployee(project.getCreatorID());
		for(Doc doc : project.getDocuments()) {
			if(doc.getName().equals(documentName)) {
				String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
				project.log("[" + dateTime + "] " +employee.getFirstName() + " "+ employee.getLastName() + " has downloaded the document " + doc.getName() +  ".\n"); 
				projectRepo.save(project);
				String message = employee.getFirstName() + " "+ employee.getLastName() + " has downloaded the document " + doc.getName();
				new Notification(message).add("plain-notification").sendAndSave(projectCreator, employeeRepo);
				return doc;
			}
		}
		throw new IOException();
	}
	
	public void close(String projectID, String employeeID) throws IOException, IllegalAccessException {
		Project project  = getProject(projectID);
		Employee employee = getEmployee(employeeID);
		if(!project.getCreatorID().equals(employeeID)) {
			throw new IllegalAccessException();
		}
		project.setClosed(true);
		project.setCloserID(employeeID);
		project.setCloserName(employee.getFirstName() + " " + employee.getLastName());
		project.setClosingTime(LocalDateTime.now());
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] The project has been closed by " + employee.getFirstName() + " "+ employee.getLastName() + ".\n"); 
		projectRepo.save(project);
	}

	public void delete(String projectID, String employeeID) throws IOException, IllegalAccessException {
		Employee admin = getEmployee(employeeID);
		Project project = getProject(projectID);
		Employee projectCreator = getEmployee(project.getCreatorID());
		if(!admin.getRole().equals("ADMIN")) {
			throw new IllegalAccessException();
		}
		String message = "Your project " + project.getTitle() + " has been deleted by the Admin.";
		new Notification(message).add("plain-notification").sendAndSave(projectCreator, employeeRepo);
		projectRepo.deleteById(projectID);
	}
	
	public void reopen(String projectID, String employeeID) throws IOException, IllegalAccessException {
		Project project  = getProject(projectID);
		Employee employee = getEmployee(employeeID);
		if(!project.getCreatorID().equals(employeeID)) {
			throw new IllegalAccessException();
		}
		project.setClosed(false);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] The project has been reopened by " + employee.getFirstName() + " "+ employee.getLastName() + ".\n"); 
		projectRepo.save(project);
		
	}
	
	public void addStep(String projectID, String stepTitle, String stepBody, String employeeID) throws IOException, IllegalAccessException {
		Project project  = getProject(projectID);
		Employee employee = getEmployee(employeeID);
		if(!project.getCreatorID().equals(employeeID)) {
			throw new IllegalAccessException();
		}
		Step step = new Step(stepTitle, stepBody, LocalDateTime.now());
		project.getSteps().add(step);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] " +employee.getFirstName() + " "+ employee.getLastName() + " has added the step " + stepTitle +  ".\n"); 
		
		projectRepo.save(project);
		
	}
	
	public void clearLog(String projectID, String employeeID) throws IOException, IllegalAccessException {
		Project project  = getProject(projectID);
		Employee admin = getEmployee(employeeID);
		Employee projectCreator = getEmployee(project.getCreatorID());
		if(!admin.getRole().equals("ADMIN")) {
			throw new IllegalAccessException();
		}
		project.setLog("");
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] The log has been cleared by " + admin.getFirstName() + " "+ admin.getLastName() + ".\n"); 
		String message = "The log for project " + project.getTitle() + " has been cleared by the Admin.";
		new Notification(message).add("plain-notification").sendAndSave(projectCreator, employeeRepo);
		projectRepo.save(project);
	}
	
	public void undoStep(String projectID, int stepNum, String employeeID) throws IOException, IllegalAccessException {
		Project project = getProject(projectID);
		if(!project.getCreatorID().equals(employeeID) || project.isClosed()) {
			throw new IllegalAccessException();
		}
		project.getStep(stepNum).setDone(false);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] The step " + project.getStep(stepNum).getTitle() +  " has been reset. \n"); 
		projectRepo.save(project);
	}
	
	public void removeStep(String projectID, int stepNum, String employeeID) throws IOException, IllegalAccessException {
		Project project = getProject(projectID);
		if(!project.getCreatorID().equals(employeeID)) {
			throw new IllegalAccessException();
		}
		project.getStep(stepNum).setRemoved(true);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] The step " + project.getStep(stepNum).getTitle() +  " has been removed. \n"); 
		projectRepo.save(project);
	}
	
	public void addDocument(MultipartFile file, String employeeID, String projectID) throws IOException, IllegalAccessException {

		Project project = getProject(projectID);
		
		if(project.isClosed()) {
			throw new IllegalAccessException();
		}
		
		Binary data = new Binary(BsonBinarySubType.BINARY, file.getBytes());
		String fileName = file.getOriginalFilename();
		String fileType = file.getContentType();
		long fileSize = file.getSize();
		
		Doc newDocument = new Doc();
		newDocument.setData(data);
		newDocument.setName(fileName);
		newDocument.setType(fileType);
		newDocument.setSize(fileSize);
		
		try {
			project.getDocuments().add(newDocument);
		}catch(NullPointerException e) {
			List<Doc> documents = new ArrayList<Doc>();

			documents.add(newDocument);
			project.setDocuments(documents);
		}
		
		Employee employee = getEmployee(employeeID);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] " +employee.getFirstName() + " "+ employee.getLastName() + " has added the document " + fileName +  ".\n"); 
		
		Employee projectCreator = getEmployee(project.getCreatorID());
		String message = employee.getFirstName() + " "+ employee.getLastName() + " has added the document " + fileName;
		new Notification(message).add("plain-notification").sendAndSave(projectCreator, employeeRepo);
		
		projectRepo.save(project);
		
	}

	public void completeStep(String projectID, int stepNum, String employeeID) throws IOException, IllegalAccessException {
		
		Employee employee = getEmployee(employeeID);
		Project project = getProject(projectID);
		if(project.isClosed()) {
			throw new IllegalAccessException();
		}
		project.getStep(stepNum).setDone(true);
		String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
		project.log("[" + dateTime + "] " +employee.getFirstName() + " "+ employee.getLastName() + " has completed the step " + project.getStep(stepNum).getTitle() +  ".\n"); 
		
		Employee projectCreator = getEmployee(project.getCreatorID());
		String message = employee.getFirstName() + " "+ employee.getLastName() + " has completed the step " + project.getStep(stepNum).getTitle();
		new Notification(message).add("plain-notification").sendAndSave(projectCreator, employeeRepo);
		
		projectRepo.save(project);
	}
	
	public void removeDocument(String projectID, String documentName, String employeeID) throws IllegalAccessException, IOException {
		Project project = getProject(projectID);
		if(!project.getCreatorID().equals(employeeID) || project.isClosed()) {
			throw new IllegalAccessException();
		}
		for(Doc doc : project.getDocuments()) {
			if(doc.getName().equals(documentName)) {
				String dateTime = LocalDateTime.now().toString().split("T")[0] + "|" + LocalDateTime.now().toString().split("T")[1].split("\\.")[0];
				project.log("[" + dateTime + "] Document " + doc.getName() +  " has been removed. \n"); 
				project.getDocuments().remove(doc);
				projectRepo.save(project);
				return;
			}
		}
		throw new IOException();
		
	}
	
}
