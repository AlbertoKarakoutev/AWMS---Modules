package com.company.awms.modules.ext.projects.data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.company.awms.modules.base.documents.data.Doc;

@Document
public class Project {
	
	@Id
	private String id;
	
	private LocalDateTime initializationTime;
	private LocalDate deadline;
	private LocalDateTime closingTime;
	
	private String title;
	private String body;
	private String creatorID;
	private String creatorName;
	private String closerID;
	private String closerName;
	private String department;
	private String log;
	
	private boolean closed;
	
	private List<Step> steps;
	private List<Doc> documents;
	
	public Project(String title, String body, String creatorID, String creatorName, LocalDateTime initializationTime, String department) {
		this.title = title;
		this.body = body;
		this.creatorID = creatorID;
		this.creatorName = creatorName;
		this.initializationTime = initializationTime;
		this.department = department;
		log = new String();
	}
	
	public String getID() {
		return id;
	}
	
	public void setID(String id) {
		this.id = id;
	}
	
	public LocalDateTime getInitializationTime() {
		return initializationTime;
	}

	public void setInitializationTime(LocalDateTime initializationTime) {
		this.initializationTime = initializationTime;
	}

	public LocalDate getDeadline() {
		return deadline;
	}

	public void setDeadline(LocalDate deadline) {
		this.deadline = deadline;
	}

	public LocalDateTime getClosingTime() {
		return closingTime;
	}

	public void setClosingTime(LocalDateTime closintTime) {
		this.closingTime = closintTime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getCreatorID() {
		return creatorID;
	}

	public void setCreatorID(String creatorID) {
		this.creatorID = creatorID;
	}

	public String getCloserID() {
		return closerID;
	}

	public void setCloserID(String closerID) {
		this.closerID = closerID;
	}

	public boolean isClosed() {
		return closed;
	}

	public void setClosed(boolean closed) {
		this.closed = closed;
	}

	public List<Step> getSteps() {
		return steps;
	}

	public Step getStep(int step) {
		return steps.get(step);
	}
	
	public void setSteps(List<Step> steps) {
		this.steps = steps;
	}

	public List<Doc> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Doc> documents) {
		this.documents = documents;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getCloserName() {
		return closerName;
	}

	public void setCloserName(String closerName) {
		this.closerName = closerName;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}
	
	public void log(String logStr) {
		log+=logStr;
	}
	
}
