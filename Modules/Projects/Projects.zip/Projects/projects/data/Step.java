package com.company.awms.modules.ext.projects.data;

import java.time.LocalDateTime;

public class Step {
	
	private String title;
	private String body;
	
	private LocalDateTime initializationTime;
	
	private boolean removed;
	private boolean done;

	public Step(String title, String body, LocalDateTime initializationTime) {
		this.title = title;
		this.body = body;
		this.initializationTime = initializationTime;
	}
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public LocalDateTime getInitializationTime() {
		return initializationTime;
	}

	public void setInitializationTime(LocalDateTime initializationTime) {
		this.initializationTime = initializationTime;
	}

	public boolean isDone() {
		return done;
	}

	public void setDone(boolean done) {
		this.done = done;
	}

	public boolean isRemoved() {
		return removed;
	}

	public void setRemoved(boolean removed) {
		this.removed = removed;
	}
	
}
