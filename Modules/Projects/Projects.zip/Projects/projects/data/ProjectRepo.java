package com.company.awms.modules.ext.projects.data;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProjectRepo extends MongoRepository<Project, String>  {

	public List<Project> findByClosed(boolean closed);
	public List<Project> findByCreatorID(String creatorID);
	public List<Project> findByDepartment(String department);
	
}
