package com.company.awms.modules.ext.projects;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.company.awms.modules.base.documents.data.Doc;
import com.company.awms.modules.base.employees.EmployeeService;
import com.company.awms.modules.ext.projects.data.Project;
import com.company.awms.security.EmployeeDetails;

@Controller
@RequestMapping("/projects")
public class ProjectsController {

	private EmployeeService employeeService;
	private ProjectService projectService;
	
	@Autowired
	public ProjectsController(EmployeeService employeeService, ProjectService projectService) {
		this.projectService = projectService;
		this.employeeService = employeeService;
	}
	
	@PostMapping(value="/create", consumes="application/json")
	public ResponseEntity<String> createProject(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestBody Object projectObj) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			}
			projectService.createProject(projectObj, employeeDetails.getID());
			
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch(IOException e) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		} catch(Exception e) {
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/addStep")
	public ResponseEntity<String> addStep(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam String stepBody, @RequestParam String stepTitle, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			}
			projectService.addStep(projectID, stepTitle, stepBody, employeeDetails.getID());
			return new ResponseEntity<String>(HttpStatus.OK);
		} catch (IOException e) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		} catch (IllegalAccessException e) {
			return new ResponseEntity<String>(HttpStatus.FORBIDDEN);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value = "/getDocument")
	public ResponseEntity<Resource> getDocument(@AuthenticationPrincipal EmployeeDetails employeeDetails, @RequestParam String documentName, @RequestParam String projectID) {
		try {
			if (!projectService.isActive()){
				new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			}
			Doc document = projectService.getDocument(projectID, documentName, employeeDetails.getID());

			ByteArrayResource byteArrayResource = new ByteArrayResource(document.getData().getData());
			return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + document.getName() + "\"").header("fileName", document.getName()).contentLength(document.getData().length())
					.contentType(MediaType.APPLICATION_OCTET_STREAM).body(byteArrayResource);
		} catch (IOException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("")
	public String getProjects(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam Optional<Integer> page) throws IOException {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			List<Project> projects = projectService.getAccessibleProjectsDTOsByPage(employeeDetails.getID(), 1);
			
			if(page.isPresent()) {
				projects =  projectService.getAccessibleProjectsDTOsByPage(employeeDetails.getID(), page.get());
			}else {
				model.addAttribute("page", 1);
			}

			model.addAttribute("pageCount", (int)Math.ceil((double)projectService.getAccessibleProjects(employeeDetails.getID()).size()/10));
			model.addAttribute("type", "all");
			model.addAttribute("projects", projects);
			return "ext/projects/projects";
		} catch(IOException e) {
			return "errors/notFound";
		} catch(Exception e) {
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/{projectID}")
	public String getProject(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			Project project = projectService.getProject(projectID);
			model.addAttribute("project", project);
			return "ext/projects/project";
		} catch(IOException e) {
			return "errors/notFound";
		} catch(Exception e) {
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/add")
	public String getAddPage(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			
			return "ext/projects/editProject";
		} catch(IOException e) {
			return "errors/notFound";
		} catch(Exception e) {
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/edit/{projectID}")
	public String getEditPage(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String  projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			model.addAttribute("type", "edit");
			model.addAttribute("project", projectService.getProject(projectID));
			
			return "ext/projects/editProject";
		} catch(IOException e) {
			return "errors/notFound";
		} catch(Exception e) {
			return "errors/internalServerError";
		}
	}
		
	@PostMapping(value="/update", consumes="application/json")
	public String updateProject(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestBody Object projectObj) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			String updatedProjectID = projectService.updateProject(projectObj, employeeDetails.getID());
			
			return "redirect:/projects/"+updatedProjectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/clearLog/{projectID}")
	public String clearLog(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.clearLog(projectID, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/delete/{projectID}")
	public String delete(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.delete(projectID, employeeDetails.getID());
			return "redirect:/projects";
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/close/{projectID}")
	public String close(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.close(projectID, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/reopen/{projectID}")
	public String reopen(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @PathVariable String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.reopen(projectID, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/completeStep")
	public String completeStep(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam int stepNum, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.completeStep(projectID, stepNum, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/undoStep")
	public String undoStep(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam int stepNum, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.undoStep(projectID, stepNum, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/removeStep")
	public String removeStep(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam int stepNum, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.removeStep(projectID, stepNum, employeeDetails.getID());
			return "redirect:/projects/edit/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
		
	@PostMapping(value = "/addDocument")
	public String addDocument(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam MultipartFile file, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.addDocument(file, employeeDetails.getID(), projectID);
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping(value = "/removeDocument")
	public String removeDocument(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam String documentName, @RequestParam String projectID) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			projectService.removeDocument(projectID, documentName, employeeDetails.getID());
			return "redirect:/projects/"+projectID;
		} catch (IOException e) {
			return "errors/notFound";
		} catch (IllegalAccessException e) {
			return "errors/notAuthorized";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
	@GetMapping("/search")
	public String searchProjects(@AuthenticationPrincipal EmployeeDetails employeeDetails, Model model, @RequestParam String searchTerm) {
		employeeService.injectLoggedInEmployeeInfo(model, employeeDetails);
		try {
			if (!projectService.isActive()){
				return "errors/notFound";
			}
			List<Project> projects = projectService.getAccessibleProjects(employeeDetails.getID());
			List<Project> foundProjects = projectService.searchProjects(projects, searchTerm);
			
			model.addAttribute("type", "search");
			model.addAttribute("projects", foundProjects);

			return "ext/projects/projects";
		} catch (IOException e) {
			return "errors/notFound";
		} catch (Exception e) {
			e.printStackTrace();
			return "errors/internalServerError";
		}
	}
	
}
